let canvas = document.getElementById("canvas");
let ctx = canvas.getContext("2d");
let nameInput = document.getElementById("nameInput");
let btnPlay = document.getElementById("btnPlay");
let permainan = document.getElementById("permainan");
let mainMenu = document.getElementById("mainMenu");
let pipes = [];
let pipeWidth = 60;
let pipeSpeed = 3;
let gapSize = 150;
let score = 0;
let tampilanGameOver = document.getElementById("gameOver");
let isGameOver = false
let waktuPermainan;
let isPaused = false
let hightScore = localStorage.getItem('hightscore')
let flapSound = new Audio("../sfx/sfx_wing.wav");
let soundScore = new Audio("../sfx/sfx_point.wav");
let nabrakPipa = new Audio('../sfx/sfx_hit.wav');
let kalah = new Audio("../sfx/sfx_die.wav");

function spawnPipe() {
  let topHeight =
    Math.floor(Math.random() * (canvas.height - gapSize - 50)) + 20;

  pipes.push({
    x: 400,
    topHeight: topHeight,
    bottomY: topHeight + gapSize,
    width: pipeWidth,
    passed: false,
  });
}

function updateScore() {
  pipes.map((p) => {
    if (!p.passed && bird.x > p.x + p.width) {
          soundScore.play();
      p.passed = true;
    
      score++;
      console.log(score);
    }
  });
}

function tampilkanScore() {
  ctx.fillStyle = "white";
  ctx.fillText(`Score: ${score}`, 20, 30);
  ctx.font = "20px Arial";
}

function updatePipes() {
  for (let i = 0; i < pipes.length; i++) {
    pipes[i].x -= pipeSpeed;
  }
}

let gambarPipaAtas = new Image();
gambarPipaAtas.src = "../assets/toppipe.png";

let gambarPipaBawah = new Image();
gambarPipaBawah.src = "../assets/bottompipe.png";

function drawPipes() {
  pipes.forEach((pipe) => {
    // PIPA ATAS
    ctx.drawImage(
      gambarPipaAtas,
      pipe.x,
      pipe.topHeight - gambarPipaAtas.height,
      pipe.width,
      gambarPipaAtas.height
    );

    // PIPA BAWAH
    ctx.drawImage(
      gambarPipaBawah,
      pipe.x,
      pipe.bottomY,
      pipe.width,
      gambarPipaBawah.height
    );
  });
}

let groundImg = new Image();
groundImg.src = "../assets/flappybirdbg.png";

let groundX = 0;
let groundSpeed = pipeSpeed; 
let groundHeight = 50;

function updateGround() {
  groundX -= groundSpeed;

 
  if (groundX <= -100) {
    groundX = 0;
  }
}

function drawGround() {
  let y = canvas.height - groundHeight;

  
  ctx.drawImage(groundImg, groundX, y, 400, groundHeight);
  ctx.drawImage(groundImg, groundX + 400, y, 400, groundHeight);
}

let bird = {
  x: 100,
  y: 200,
  width: 20,
  height: 24,
  velocity: 0,
  gravity: 0.4,
  jumpStrength: 8,
  rotation: 0,
};

let birdImg = new Image();
birdImg.src = "../assets/flappybird.png";

function flap() {
    
        if (isPaused || isGameOver || mainMenu.style.display !== "none") {
        return;
    }
    
  bird.velocity = -bird.jumpStrength;
   flapSound.currentTime = 0;   
  flapSound.play();
}

document.addEventListener("keydown", (e) => {
  if (e.code === "Space" || e.code === "ArrowUp") {
    flap();
  }
});

canvas.addEventListener("click", flap);

function updateBird() {
  bird.velocity += bird.gravity;
  bird.y += bird.velocity;

  if (bird.velocity < 0) {
    bird.rotation = (-20 * Math.PI) / 180;
  } else {
    bird.rotation = (Math.min(bird.velocity * 3, 90) * Math.PI) / 180;
  }

  if (bird.y + bird.height > 600) {
    bird.y = 600 - bird.height;
    bird.velocity = 0;
  }
}

function checkCollision() {

  if (bird.y < 1) {
    kalah.play();
    return true;
  }


  if (bird.y + bird.height > 595) {
    kalah.play();
    return true;
  }

 
  for (let i = 0; i < pipes.length; i++) {
    let pipe = pipes[i];

   
    let horizontallyAligned =
      bird.x + 10 > pipe.x && bird.x < pipe.x + pipe.width;

    if (horizontallyAligned) {
     
      if (bird.y < pipe.topHeight) {
        nabrakPipa.play()
        
        return true;
      }

     
      if (bird.y + bird.height > pipe.bottomY) {
        nabrakPipa.play()
        
        return true;
      }
    }
  }


  return false;
}

function drawBird() {
  ctx.save();
  ctx.translate(bird.x, bird.y);
  ctx.rotate(bird.rotation);

  ctx.drawImage(
    birdImg,
    -bird.width / 2,
    -bird.height / 2,
    bird.width,
    bird.height
  );

  ctx.restore();
}

function playGame() {

  mainMenu.style.display = "none";
  permainan.style.display = "block";
  resetGame();
  waktuPermainan = setInterval(spawnPipe, 2000);
}

nameInput.addEventListener("input", () => {
  if (nameInput.value === "") {
    btnPlay.disabled = true;
  } else {
    btnPlay.disabled = false;
  }
});

function gameLoop() {

  ctx.clearRect(0, 0, 400, 600);

  updateGround();
  drawGround();
  drawPipes();
  updatePipes();
  updateBird();
  updateScore();

  drawBird();

  if (checkCollision()) {
    console.log("GAME OVER");
    gameOver();
    return;
  }

  tampilkanScore();
      if (isGameOver) {
        clearInterval(waktuPermainan);
        return
    }
    
    if (isPaused === true) {
         return
    } 

  requestAnimationFrame(gameLoop);
}

function resetGame() {
  bird = {
    x: 100,
    y: 200,
    width: 30,
    height: 24,
    velocity: 0,
    gravity: 0.4,
    jumpStrength: 8,
    rotation: 0,
  };

  gameLoop();
}

let iniScore = document.getElementById('iniScore');
let iniHightScore = document.getElementById("iniHightScore");

function gameOver() {
    tampilanGameOver.style.display = "block";
    isGameOver = true
    if (score > hightScore) {
        
   
        localStorage.setItem('hightscore', score)
          iniScore.textContent = `Anda mendapat score tinggi baru!! ${score}`
    iniHightScore.textContent =   `Hightscore sebelumnya: ${hightScore}`
    }
    
    else {
            iniScore.textContent = `Your Score ${score}`
    iniHightScore.textContent =   `Hightscore ${hightScore}`
    }

    
}


function playAgain () {
    hightScore = localStorage.getItem('hightscore')
      isGameOver = false
      score = 0;
    pipes = [];
    groundX = 0;
    bird = {
    x: 100,
    y: 200,
    width: 30,
    height: 24,
    velocity: 0,
    gravity: 0.4,
    jumpStrength: 8,
    rotation: 0,
  };
      clearInterval(waktuPermainan);
    waktuPermainan = setInterval(spawnPipe, 2000);
    tampilanGameOver.style.display = "none"
    pauseBtn.disabled = false
    
  gameLoop();
}

let tampilanPause = document.getElementById('tampilanPause');
let pauseBtn = document.getElementById('pauseBtn');

function pause() {
    clearInterval(waktuPermainan);
    isPaused = true
    tampilanPause.style.display = "block"
    pauseBtn.disabled = true
}




function resume() {
    isPaused = false;
    pauseBtn.disabled = false

    clearInterval(waktuPermainan);
    waktuPermainan = setInterval(spawnPipe, 2000);

    
    tampilanPause.style.display = "none";

    gameLoop();
}




document.addEventListener("keydown", function(e) {
    if (mainMenu.style.display !== "none") {   
        if (e.key === "Enter") {
            btnPlay.click();  
        }
    }
});




document.addEventListener("keydown", function(e) {

   
    if (e.key === "Escape") {
        if (!isPaused && !isGameOver && permainan.style.display === "block") {
            pause();  
        } 
        else if (isPaused) {
            resume();  
        }
    }
});

