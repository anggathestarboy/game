let mainMenu = document.getElementById("mainMenu");
let permainan = document.getElementById("permainan");
let canvas = document.getElementById("canvas");
let ctx = canvas.getContext("2d");

let btnPlay = document.getElementById("btnPlay");

let nameInput = document.getElementById("nameInput");
let gambarKey = new Image();
gambarKey.src = `../images/key.png`
let waktuAkhir = "00:00";

let gambarVirus = new Image();
gambarVirus.src = `../images/corona.png`
let fail = 0;
let score = 0
let waktuPermainan;
let hitungMundur = 3;
let isPaused = false;
let isGameRunning = false;

const pauseOverlay = document.getElementById("pauseOverlay");
const btnContinue = document.getElementById("btnContinue");
const btnRestart = document.getElementById("btnRestart");

let restartBtn = {
  x: 100,
  y: 420,
  w: 200,
  h: 50
};
let timerHitungMundur;

let timerEl = document.getElementById("timer");
let scoreEl = document.getElementById("score");

let detik = 0

let waktuBermain;

let isGameOver = false



function tampilanDetik() {
  detik++;

  let waktuDetik = detik % 60;
  let waktuMenit = Math.floor(detik / 60);

  let detikStr = String(waktuDetik).padStart(2, "0");
  let menitStr = String(waktuMenit).padStart(2, "0");

  waktuAkhir = `${menitStr}:${detikStr}`;
  timerEl.textContent = waktuAkhir;
}








const areaKolom = [
  {
    xMin:0, xMax: 100
  }, {
    xMin:100,xMax: 200
  },
  {
    xMin: 200, xMax:300
  },
  {
    xMin:300, xMax: 400
  }
]


let virusList = [];


function spawnVirus() {
  let kolomRandom = areaKolom[Math.floor(Math.random() * areaKolom.length)];

  let virus = {
    x: Math.random() * (kolomRandom.xMax - kolomRandom.xMin - 40) + kolomRandom.xMin,
    y: -40,
    w: 40,
    h: 40,
    speed: 3
  };

  virusList.push(virus);
}




function drawVirus() {
  virusList.forEach((virus) => {
    ctx.drawImage(gambarVirus, virus.x, virus.y, virus.w, virus.h);
    virus.y += virus.speed;
  });


  virusList = virusList.filter(v => v.y < canvas.height);
}


document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    if (isGameOver) return;

    isPaused ? resumeGame() : pauseGame();
  }
});


function pauseGame() {
  isPaused = true;
  pauseOverlay.style.display = "flex";

  clearInterval(waktuPermainan);
  clearInterval(waktuBermain);
  clearInterval(timerHitungMundur);
}


function resumeGame() {
  isPaused = false;
  pauseOverlay.style.display = "none";

  if (hitungMundur > 0) {
    timerHitungMundur = setInterval(fungsiHitungMundur, 1000);
  } else {
    waktuBermain = setInterval(tampilanDetik, 1000);
    waktuPermainan = setInterval(spawnVirus, 1000);
  }
}



btnContinue.addEventListener("click", resumeGame);

btnRestart.addEventListener("click", () => {
  pauseOverlay.style.display = "none";
  restartGame();
});



let posisiBatas = {
    x: 0,
    y: 550,
    w: 400,
    h: 20
}

const keyMap = {
  d: { xMin: 0,   xMax: 100 },
  f: { xMin: 100, xMax: 200 },
  j: { xMin: 200, xMax: 300 },
  k: { xMin: 300, xMax: 400 },
};


let tampilanScore = document.getElementById("score");


document.addEventListener("keydown", (e) => {
  const key = e.key.toLowerCase();
  if (!keyMap[key]) return;

  lights[key] = true; // nyalakan light

  const kolom = keyMap[key];

  virusList = virusList.filter((virus) => {

    const diDanger =
      virus.y + virus.h > posisiAreaDanger.y &&
      virus.y < posisiAreaDanger.y + posisiAreaDanger.h;

    const diKolom =
      virus.x >= kolom.xMin &&
      virus.x + virus.w <= kolom.xMax;

    if (diDanger && diKolom) {
      score++;
      tampilanScore.textContent = `Score: ${score}`
      return false;
    }

    return true;
  });
});


document.addEventListener("keyup", (e) => {
  const key = e.key.toLowerCase();
  if (!lights.hasOwnProperty(key)) return;

  lights[key] = false;
});


let lights = {
  d: false,
  f: false,
  j: false,
  k: false,
};





function drawLight(key) {
  const kolom = keyMap[key];
  const tinggiLight = 156;

  const x = kolom.xMin;
  const y = posisiBatas.y - tinggiLight;


  const gradient = ctx.createLinearGradient(
    0,
    y,
    0,
    y + tinggiLight
  );

  gradient.addColorStop(0, "rgba(0, 255, 255, 0)");
  gradient.addColorStop(1, "rgba(0, 255, 255, 0.8)");

  ctx.fillStyle = gradient;
  ctx.fillRect(x, y, 100, tinggiLight);
}




let posisiAreaDanger = {
    x: 0,
    y: 400,
    w: 400,
    h: 150,
}

let tampilanFail = document.getElementById("fail")
let getScore = localStorage.getItem("score");
let getWaktu = localStorage.getItem("waktu")




function gameOver() {
  ctx.fillStyle = "rgba(0,0,0,0.8)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = "#ff5252";
  ctx.font = "bold 42px Arial";
  ctx.textAlign = "center";
  ctx.fillText("GAME OVER", canvas.width / 2, 200);

  ctx.fillStyle = "white";
  ctx.font = "20px Arial";
  ctx.fillText(`Player : ${localStorage.getItem("name")}`, canvas.width / 2, 260);
  ctx.fillText(`Score  : ${score}`, canvas.width / 2, 300);
  ctx.fillText(`Time   : ${waktuAkhir}`, canvas.width / 2, 340);

  // tombol restart
  ctx.fillStyle = "#00e676";
  ctx.fillRect(restartBtn.x, restartBtn.y, restartBtn.w, restartBtn.h);

  ctx.fillStyle = "black";
  ctx.font = "bold 22px Arial";
  ctx.fillText("RESTART", canvas.width / 2, restartBtn.y + 33);
}

canvas.addEventListener("click", (e) => {
  if (!isGameOver) return;

  const rect = canvas.getBoundingClientRect();
  const mouseX = e.clientX - rect.left;
  const mouseY = e.clientY - rect.top;

  if (
    mouseX >= restartBtn.x &&
    mouseX <= restartBtn.x + restartBtn.w &&
    mouseY >= restartBtn.y &&
    mouseY <= restartBtn.y + restartBtn.h
  ) {
    restartGame();
  }
});


function restartGame() {
  score = 0;
  fail = 0;
  detik = 0;
  hitungMundur = 3;
  virusList = [];
  isGameOver = false;

  waktuPermainan = null; // PENTING
  waktuAkhir = "00:00";

  tampilanScore.textContent = "Score: 0";
  tampilanFail.textContent = "Fail: 0";
  timerEl.textContent = "00:00";

  clearInterval(waktuPermainan);
  clearInterval(waktuBermain);
  clearInterval(timerHitungMundur);

  timerHitungMundur = setInterval(fungsiHitungMundur, 1000);
  // waktuBermain = setInterval(tampilanDetik, 1000);


}






function deteksi() {
  virusList = virusList.filter((virus) => {
    if (
      virus.x < posisiBatas.x + posisiBatas.w &&
      virus.x + virus.w > posisiBatas.x &&
      virus.y < posisiBatas.y + posisiBatas.h &&
      virus.y + virus.h > posisiBatas.y
    ) {
      fail++;
      tampilanFail.textContent = `Fail: ${fail}`;

      if (fail >= 5) {
        isGameOver = true;

        localStorage.setItem("score", score);
        localStorage.setItem("waktu", waktuAkhir);

        clearInterval(waktuPermainan);
        clearInterval(waktuBermain);
      }
      return false;
    }
    return true;
  });
}



function fungsiHitungMundur() {
  hitungMundur--;

  if (hitungMundur <= 0) {
    clearInterval(timerHitungMundur);

    // ⏱️ TIMER BARU JALAN SETELAH COUNTDOWN
    waktuBermain = setInterval(tampilanDetik, 1000);

    // 👾 SPAWN VIRUS
    waktuPermainan = setInterval(spawnVirus, 1000);
  }
}







function drawDanger() {
    ctx.beginPath();
    ctx.fillStyle = "rgba(170, 0, 0, 0.38)";
    ctx.fillRect(posisiAreaDanger.x, posisiAreaDanger.y, posisiAreaDanger.w, posisiAreaDanger.h)
    ctx.closePath();
}

nameInput.addEventListener("input", (e) => {
  if (nameInput.value !== "") {
    btnPlay.disabled = false;
  } else {
    btnPlay.disabled = true;
  }
});


function drawPosisiBatas() {
    ctx.beginPath();
    ctx.fillStyle = "gray";
    ctx.fillRect(posisiBatas.x,posisiBatas.y,posisiBatas.w,posisiBatas.h)
    ctx.closePath();
}

function garisBatas() {
  ctx.beginPath();
  ctx.strokeStyle = "gray";
  ctx.moveTo(100, 0);
  ctx.lineTo(100, 700);
  ctx.stroke();

  ctx.closePath();


  ctx.beginPath();

    ctx.strokeStyle = "gray";
  ctx.moveTo(200, 0);
  ctx.lineTo(200, 700);
  ctx.stroke();

  ctx.closePath();

  ctx.beginPath();

    ctx.strokeStyle = "gray";
  ctx.moveTo(300, 0);
  ctx.lineTo(300, 700);
  ctx.stroke();

  ctx.closePath();


}


function drawKey() {
     ctx.beginPath();
    ctx.fillStyle =    "#6061b1"
    ctx.fillRect(0,570,100,190)
    ctx.closePath();
     ctx.beginPath();
    ctx.fillStyle =    "#3d8db2"
    ctx.fillRect(100,570,100,190)
    ctx.closePath();
     ctx.beginPath();
    ctx.fillStyle =    "#6061b1"
    ctx.fillRect(200,570,100,190)
    ctx.closePath();
     ctx.beginPath();
    ctx.fillStyle =    "#3d8db2"
    ctx.fillRect(300,570,100,190)
    ctx.closePath();
    ctx.drawImage(gambarKey, 20,580,350,100)
   
}

let playerName = document.getElementById("name");
let getName = localStorage.getItem("name")

function playGame() {
  mainMenu.style.display = "none";
  permainan.style.display = "block";

  hitungMundur = 3;
  isPaused = false;
  isGameOver = false;

  localStorage.setItem("name", nameInput.value);
  playerName.innerText = nameInput.value;

  timerHitungMundur = setInterval(fungsiHitungMundur, 1000);
  waktuBermain = setInterval(tampilanDetik, 1000);

  if (!isGameRunning) {
    isGameRunning = true;
    requestAnimationFrame(gameManager);
  }
}





function gameManager() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // LOOP TIDAK PERNAH MATI
  requestAnimationFrame(gameManager);

  // COUNTDOWN
  if (hitungMundur > 0) {
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "white";
    ctx.font = "bold 80px Arial";
    ctx.textAlign = "center";
    ctx.fillText(hitungMundur, canvas.width / 2, canvas.height / 2);
    return;
  }

  // PAUSE → STOP LOGIC SAJA
  if (isPaused) return;

  garisBatas();
  drawDanger();

  if (isGameOver) {
    gameOver();
    clearInterval(waktuBermain)
    return;
  }

  if (lights.d) drawLight("d");
  if (lights.f) drawLight("f");
  if (lights.j) drawLight("j");
  if (lights.k) drawLight("k");

  drawKey();
  drawPosisiBatas();
  drawVirus();
  deteksi();
}

