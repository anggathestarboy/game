let mainMenu = document.getElementById("mainMenu");
let canvas = document.getElementById("canvas");
let mainScene = document.getElementById("mainScene");
let tampilanScore = document.getElementById("tampilanScore");
let ctx = canvas.getContext("2d");
let cursor = { x: 0, y: 0 };
let cursorSize = 50;
let targets = [];
let lives = 3;
interval = null;

let gameFinished = false;

let gameFinishedDiv = document.getElementById("gameFinished");
let finishedContent = document.getElementById("finishedContent");
let finishedHighScore = document.getElementById("finishedHighScore");

let maxTarget = 5;
let minTarget = 1;
let speedTarget = 3;
let targetImg = new Image();
targetImg.src = "assets/target.png";
let score = 0;
let detik = 60;
let isGameOver = false;
let archeryHightScore = localStorage.getItem("archeryHightScore");
let mati = document.getElementById("mati");

let gameRunning = false;

let tampilanNyawa = document.getElementById("tampilanNyawa");

function nyawa() {
  tampilanNyawa.innerHTML = "";

  for (let i = 0; i < lives; i++) {
    let bentukNyawa = document.createElement("img");
    bentukNyawa.src = "assets/hearth.png";
    tampilanNyawa.append(bentukNyawa);
  }
}

function spawnTarget() {
  if (targets.length >= maxTarget) return;

  targets.push({
    x: Math.random() * (960 - 60),
    y: 600,                // spawn dari bawah
    size: 60,

    velocityY: -13,        // naik cepat (minus = ke atas)
    gravity: 0.2,          // gravitasi makin besar = makin cepat jatuh
  });
}


function tampilanGameFinished() {
  gameFinishedDiv.style.display = "block";
  gameFinished = true;

  if (score > archeryHightScore) {
    finishedContent.textContent = `Highscore baru!! ${score}`;
    finishedHighScore.textContent = `HighScore Sebelumnya: ${archeryHightScore}`;
    localStorage.setItem("archeryHightScore", score);
  } else {
    finishedContent.textContent = `Score Anda ${score}`;
    finishedHighScore.textContent = `HighScore: ${archeryHightScore}`;
  }

  mati.disabled = true;
}



function updateTarget() {
  for (let i = targets.length - 1; i >= 0; i--) {
    let t = targets[i];

    // terapkan gravitasi
    t.y += t.velocityY;
    t.velocityY += t.gravity;

    // jika jatuh ke bawah → miss
    if (t.y >= 600) {
      targets.splice(i, 1);
      lives--;
      score -= 5;
      nyawa();

      if (lives <= 0) {
        tampilanGameOver();
        saveLeaderboard();
        clearInterval(interval);

        if (!archeryHightScore || score > archeryHightScore) {
          localStorage.setItem("archeryHightScore", score);
        }

        isGameOver = true;
      }
    }
  }
}


let nameInput = document.getElementById("nameInput");
let playBtn = document.getElementById("playBtn");

nameInput.addEventListener("input", () => {
  if (nameInput.value.trim() !== "") {
    playBtn.disabled = false;
  } else {
    playBtn.disabled = true;
  }
});

let tampilanTimer = document.getElementById("tampilanTimer");

function iniTimer() {
  let menit = Math.floor((detik % 60) / 60);
  let detikStr = String(detik).padStart(2, "0");
  let menitStr = String(menit).padStart(2, "0");
  tampilanTimer.textContent = `${menitStr}:${detikStr}`;
  console.log(detikStr);
  detik--;

if (detik <= -1) {
    clearInterval(interval);
    tampilanGameFinished();  // <--- BEDAKAN!
    saveLeaderboard();
    return;
}

}

let gameOver = document.getElementById("gameOver");
let content = document.getElementById("content");
let tampilanHightScore = document.getElementById("hightScore");


function tampilanGameOver() {
  gameOver.style.display = "block";
  if (score > archeryHightScore) {
    content.textContent = `Hightscore baru!! ${score}`;
    tampilanHightScore.textContent = `HightScore Sebelumnya: ${archeryHightScore}`;
  } else {
    content.textContent = `Score Anda ${score}`;
    tampilanHightScore.textContent = `HightScore: ${archeryHightScore}`;
  }
  mati.disabled = true
}

function saveLeaderboard() {
  let nama = nameInput.value;
  let leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];

  leaderboard.push({
    nama: nama,
    skor: score,
  });

  leaderboard.sort((a, b) => b.skor - a.skor);
  leaderboard = leaderboard.slice(0, 10);

  localStorage.setItem("leaderboard", JSON.stringify(leaderboard));
}

function drawTarget() {
  targets.map((t) => {
    ctx.drawImage(targetImg, t.x, t.y, t.size, t.size);
  });
}

function ensureMinimumTarget() {
  if (targets.length < minTarget) {
    spawnTarget();
  }
}

let isPaused = false;
let tampilanGamePause = document.getElementById("gamePause");
function buatPause() {
  isPaused = true;
  clearInterval(interval);

  tampilanGamePause.style.display = "block";
}

function resetGame() {
    mati.disabled = false
    
  score = 0;
  detik = 60;
  lives = 3;
  isGameOver = false;
  targets = [];
  isPaused = false;

  tampilanScore.textContent = "Score: 0";
  tampilanTimer.textContent = "01:00";
  nyawa();

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  clearInterval(interval);
  interval = setInterval(iniTimer, 1000);
  tampilanGamePause.style.display = "none";
gameOver.style.display = "none";
gameFinishedDiv.style.display = "none";
gameFinished = false;

}

canvas.addEventListener("mousemove", (e) => {
  let rect = canvas.getBoundingClientRect();
  cursor.x = e.clientX - rect.left;
  cursor.y = e.clientY - rect.top;
});

function deteksi() {
  canvas.addEventListener("click", (e) => {
    let rect = canvas.getBoundingClientRect();
    cursor.x = e.clientX - rect.left;
    cursor.y = e.clientY - rect.top;

    for (let i = targets.length - 1; i >= 0; i--) {
      let t = targets[i];

      if (
        cursor.x > t.x &&
        cursor.y > t.y &&
        cursor.x < t.x + t.size &&
        cursor.y < t.y + t.size
      ) {
        targets.splice(i, 1);
        score+=10;
        tampilanScore.textContent = `Score: ${score}`;
      }
    }
  });
}


document.addEventListener('keydown', (e) => {
    if (e.key === "Escape") {
     buatPause();
    }
})

function resume() {
  isPaused = false;
  tampilanGamePause.style.display = "none";
  interval = setInterval(iniTimer, 1000);
  mati.disabled = false
}

function kembalilah() {
  window.location.href = "index.html";
    mati.disabled = false
}




function showLeaderboard() {
  let leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
  let board = document.getElementById("leaderboard");
  board.innerHTML = "<h3>Leaderboard</h3>";
  leaderboard.map((l, index) => {
    let row = document.createElement("p");
    row.textContent = `${index + 1}. ${l.nama} - ${l.skor}`;
    board.append(row);
  });
}

function playGame() {
  mainMenu.style.display = "none";
  mainScene.style.display = "block";

  if (!gameRunning) {
    gameRunning = true;
    gameManager();
    nyawa();
    interval = setInterval(iniTimer, 1000);
  }
}

function drawScope() {
  let img = new Image();
  img.src = "../assets/cursor-scope.jpeg";
  ctx.clearRect(0, 0, 960, 600);
  drawTarget();

  ctx.drawImage(img, cursor.x - 25, cursor.y - 25, cursorSize, cursorSize);
}


function tampilSkor() {
      tampilanScore.textContent = `Score: ${score}`;
}

function gameManager() {
  requestAnimationFrame(gameManager);

  if (isPaused) {
    return;
  }
  if (isGameOver) {
    return;
  }
  
  if (gameFinished) {
    return
  }
  updateTarget();
  ensureMinimumTarget();
  drawScope();
  
  showLeaderboard();
  tampilSkor();
deteksi();
  
}

clearInterval(interval);



document.addEventListener("keydown", (e) => {
    
    if (e.key === "Enter" && nameInput.value.trim() !== "") {

       
        playBtn.disabled = false;

    
        playGame();
    }
});


